package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.TopupRepository
import com.example.data.UidVerificationResult
import com.example.model.AuthProvider
import com.example.model.OrderStatus
import com.example.model.PackageCategory
import com.example.model.PaymentMethodInfo
import com.example.model.PaymentMethods
import com.example.model.PaymentType
import com.example.model.TopupOrder
import com.example.model.TopupPackage
import com.example.model.TopupPackages
import com.example.model.UserProfile
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

data class CheckoutUiState(
    val selectedPackage: TopupPackage = TopupPackages.ALL.first { it.id == "pkg_1090" },
    val filterCategory: PackageCategory? = null,
    val playerUid: String = "2847193021",
    val verifiedIgn: String? = "★⚡RASTAR_FF⚡★",
    val verifiedLevel: Int = 68,
    val isVerifyingUid: Boolean = false,
    val uidError: String? = null,
    val selectedPayment: PaymentMethodInfo = PaymentMethods.ALL[0],
    val transactionId: String = "",
    val senderNumber: String = "",
    val screenshotUri: String? = null,
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
    val showCheckoutSuccessDialog: Boolean = false,
    val newlyPlacedOrderId: String? = null
)

class TopupViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TopupRepository

    init {
        val db = AppDatabase.getInstance(application)
        repository = TopupRepository(db.orderDao())
    }

    val ordersList: StateFlow<List<TopupOrder>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(CheckoutUiState())
    val uiState: StateFlow<CheckoutUiState> = _uiState.asStateFlow()

    private val _activeTrackOrderId = MutableStateFlow<String?>("FF-89214")
    val activeTrackOrderId: StateFlow<String?> = _activeTrackOrderId.asStateFlow()

    private val _userProfile = MutableStateFlow(
        UserProfile(
            isLoggedIn = true,
            authProvider = AuthProvider.PHONE,
            displayName = "Topup Pro BD",
            identifier = "+880 1712-345678",
            savedUids = listOf("2847193021", "1049281745"),
            totalOrders = 3,
            totalDiamondsOrdered = 4320
        )
    )
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    fun selectTab(index: Int) {
        _selectedTab.value = index
    }

    fun selectPackage(pkg: TopupPackage) {
        _uiState.value = _uiState.value.copy(selectedPackage = pkg)
    }

    fun setCategoryFilter(category: PackageCategory?) {
        _uiState.value = _uiState.value.copy(filterCategory = category)
    }

    fun onUidChanged(newUid: String) {
        val filtered = newUid.filter { it.isDigit() }
        _uiState.value = _uiState.value.copy(
            playerUid = filtered,
            verifiedIgn = null,
            uidError = null
        )
    }

    fun verifyPlayerUid() {
        val currentUid = _uiState.value.playerUid
        if (currentUid.isBlank()) {
            _uiState.value = _uiState.value.copy(uidError = "Please enter Free Fire Player UID")
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isVerifyingUid = true, uidError = null)
            val result = repository.verifyUid(currentUid)
            if (result.isValid) {
                _uiState.value = _uiState.value.copy(
                    isVerifyingUid = false,
                    verifiedIgn = result.ign,
                    verifiedLevel = result.level,
                    uidError = null
                )
                _toastEvent.emit("UID Verified: ${result.ign} (Lv. ${result.level})")
            } else {
                _uiState.value = _uiState.value.copy(
                    isVerifyingUid = false,
                    verifiedIgn = null,
                    uidError = result.errorMessage
                )
            }
        }
    }

    fun selectPayment(method: PaymentMethodInfo) {
        _uiState.value = _uiState.value.copy(selectedPayment = method)
    }

    fun onTransactionIdChanged(txnId: String) {
        _uiState.value = _uiState.value.copy(transactionId = txnId)
    }

    fun onSenderNumberChanged(number: String) {
        _uiState.value = _uiState.value.copy(senderNumber = number)
    }

    fun onScreenshotSelected(uri: String?) {
        _uiState.value = _uiState.value.copy(screenshotUri = uri)
    }

    fun setSampleScreenshot() {
        // Mock sample receipt for testing in emulator environments
        _uiState.value = _uiState.value.copy(
            screenshotUri = "sample_receipt_${System.currentTimeMillis()}",
            transactionId = if (_uiState.value.transactionId.isBlank()) {
                "${_uiState.value.selectedPayment.name.take(3).uppercase()}-${Random.nextInt(10000000, 99999999)}"
            } else _uiState.value.transactionId,
            senderNumber = if (_uiState.value.senderNumber.isBlank()) "9801" + Random.nextInt(100000, 999999) else _uiState.value.senderNumber
        )
    }

    fun submitTopupOrder() {
        val state = _uiState.value

        if (state.playerUid.length < 8) {
            _uiState.value = state.copy(errorMessage = "Enter valid 8-11 digit Free Fire UID")
            return
        }

        if (state.transactionId.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Please enter Transaction / Reference ID")
            return
        }

        if (state.screenshotUri == null) {
            _uiState.value = state.copy(errorMessage = "Please upload or attach payment screenshot")
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSubmitting = true, errorMessage = null)

            val orderId = "FF-" + Random.nextInt(10000, 99999)
            val ign = state.verifiedIgn ?: "Gamer_${state.playerUid.takeLast(4)}"

            val newOrder = TopupOrder(
                orderId = orderId,
                playerUid = state.playerUid,
                playerName = ign,
                serverRegion = "BD (Bangladesh)",
                packageId = state.selectedPackage.id,
                packageTitle = state.selectedPackage.name,
                diamondsAmount = state.selectedPackage.diamonds,
                price = state.selectedPackage.price,
                paymentMethod = state.selectedPayment.name,
                transactionId = state.transactionId.trim(),
                senderNumber = state.senderNumber.ifBlank { "9800000000" },
                screenshotUri = state.screenshotUri,
                status = OrderStatus.PENDING,
                statusNote = "Order received! System verifying transaction proof with ${state.selectedPayment.name}."
            )

            repository.placeOrder(newOrder)

            // Update user profile stats and saved UIDs
            val currentProfile = _userProfile.value
            val updatedUids = (currentProfile.savedUids + state.playerUid).distinct()
            _userProfile.value = currentProfile.copy(
                savedUids = updatedUids,
                totalOrders = currentProfile.totalOrders + 1,
                totalDiamondsOrdered = currentProfile.totalDiamondsOrdered + state.selectedPackage.diamonds
            )

            _activeTrackOrderId.value = orderId
            _uiState.value = _uiState.value.copy(
                isSubmitting = false,
                showCheckoutSuccessDialog = true,
                newlyPlacedOrderId = orderId
            )
            _toastEvent.emit("Order $orderId placed successfully!")
        }
    }

    fun dismissSuccessDialogAndTrack() {
        val orderId = _uiState.value.newlyPlacedOrderId
        _uiState.value = _uiState.value.copy(
            showCheckoutSuccessDialog = false,
            transactionId = "",
            screenshotUri = null
        )
        if (orderId != null) {
            _activeTrackOrderId.value = orderId
            _selectedTab.value = 1 // Switch to Track Tab
        }
    }

    fun setActiveTrackOrder(orderId: String) {
        _activeTrackOrderId.value = orderId
        _selectedTab.value = 1
    }

    fun fastTrackSimulate(orderId: String) {
        viewModelScope.launch {
            _toastEvent.emit("Starting live top-up simulation...")
            repository.simulateLiveProcessing(orderId) { nextStatus ->
                viewModelScope.launch {
                    _toastEvent.emit("Status Update: ${nextStatus.title}")
                }
            }
        }
    }

    // Authentication methods
    fun loginWithPhone(phone: String, otp: String) {
        _userProfile.value = UserProfile(
            isLoggedIn = true,
            authProvider = AuthProvider.PHONE,
            displayName = "Player " + phone.takeLast(4),
            identifier = phone,
            savedUids = _userProfile.value.savedUids,
            totalOrders = _userProfile.value.totalOrders,
            totalDiamondsOrdered = _userProfile.value.totalDiamondsOrdered
        )
        viewModelScope.launch {
            _toastEvent.emit("Welcome! Logged in with $phone")
        }
    }

    fun loginWithGoogle(accountName: String, email: String) {
        _userProfile.value = UserProfile(
            isLoggedIn = true,
            authProvider = AuthProvider.GOOGLE,
            displayName = accountName,
            identifier = email,
            savedUids = _userProfile.value.savedUids,
            totalOrders = _userProfile.value.totalOrders,
            totalDiamondsOrdered = _userProfile.value.totalDiamondsOrdered
        )
        viewModelScope.launch {
            _toastEvent.emit("Signed in with Google: $email")
        }
    }

    fun logout() {
        _userProfile.value = UserProfile(
            isLoggedIn = false,
            authProvider = AuthProvider.GUEST,
            displayName = "Guest Gamer",
            identifier = "Not logged in",
            savedUids = _userProfile.value.savedUids,
            totalOrders = _userProfile.value.totalOrders,
            totalDiamondsOrdered = _userProfile.value.totalDiamondsOrdered
        )
        viewModelScope.launch {
            _toastEvent.emit("Logged out")
        }
    }
}
