package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.model.OrderStatus
import com.example.model.TopupOrder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Converters {
    @TypeConverter
    fun fromOrderStatus(status: OrderStatus): String = status.name

    @TypeConverter
    fun toOrderStatus(value: String): OrderStatus = try {
        OrderStatus.valueOf(value)
    } catch (_: Exception) {
        OrderStatus.PENDING
    }
}

@Database(entities = [TopupOrder::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ff_topup_db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Prepopulate sample initial active order for instant demonstration
                        CoroutineScope(Dispatchers.IO).launch {
                            val sample = TopupOrder(
                                orderId = "FF-89214",
                                playerUid = "2847193021",
                                playerName = "★⚡RASTAR_FF⚡★",
                                serverRegion = "BD (Bangladesh)",
                                packageId = "pkg_1090",
                                packageTitle = "1090 Diamonds",
                                diamondsAmount = 1090,
                                price = 925,
                                paymentMethod = "eSewa",
                                transactionId = "ESW-90218402",
                                senderNumber = "9812345678",
                                screenshotUri = null,
                                status = OrderStatus.PROCESSING,
                                statusNote = "Garena BD server API in-progress. Credits shortly.",
                                createdAt = System.currentTimeMillis() - (1000 * 60 * 3),
                                updatedAt = System.currentTimeMillis()
                            )
                            INSTANCE?.orderDao()?.insertOrder(sample)
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
