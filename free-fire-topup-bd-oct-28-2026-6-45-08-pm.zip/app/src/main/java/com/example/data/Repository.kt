package com.example.data

import com.example.model.AuthProvider
import com.example.model.OrderStatus
import com.example.model.TopupOrder
import com.example.model.UserProfile
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlin.random.Random

data class UidVerificationResult(
    val isValid: Boolean,
    val uid: String,
    val ign: String? = null,
    val level: Int = 0,
    val region: String = "BD (Bangladesh)",
    val errorMessage: String? = null
)

class TopupRepository(private val orderDao: OrderDao) {

    val allOrders: Flow<List<TopupOrder>> = orderDao.getAllOrders()

    fun getOrderFlow(orderId: String): Flow<TopupOrder?> = orderDao.getOrderFlow(orderId)

    suspend fun getOrderById(orderId: String): TopupOrder? = orderDao.getOrderById(orderId)

    suspend fun placeOrder(order: TopupOrder) {
        orderDao.insertOrder(order)
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: OrderStatus, note: String? = null) {
        val existing = orderDao.getOrderById(orderId) ?: return
        val updated = existing.copy(
            status = newStatus,
            statusNote = note ?: newStatus.description,
            updatedAt = System.currentTimeMillis()
        )
        orderDao.updateOrder(updated)
    }

    suspend fun simulateLiveProcessing(orderId: String, onStep: (OrderStatus) -> Unit) {
        val steps = listOf(
            OrderStatus.PENDING,
            OrderStatus.VERIFYING,
            OrderStatus.PROCESSING,
            OrderStatus.COMPLETED
        )

        val current = orderDao.getOrderById(orderId) ?: return
        val startIdx = steps.indexOf(current.status).coerceAtLeast(0)

        for (i in (startIdx + 1) until steps.size) {
            delay(3500) // 3.5s per step in fast-track simulation
            val nextStatus = steps[i]
            updateOrderStatus(
                orderId = orderId,
                newStatus = nextStatus,
                note = when (nextStatus) {
                    OrderStatus.VERIFYING -> "Payment gateway receipt confirmed. Matching with reference ID."
                    OrderStatus.PROCESSING -> "Connecting to Free Fire BD Server. Injecting diamond payload."
                    OrderStatus.COMPLETED -> "SUCCESS! Diamonds credited to Player UID ${current.playerUid}."
                    else -> nextStatus.description
                }
            )
            onStep(nextStatus)
        }
    }

    suspend fun verifyUid(uid: String): UidVerificationResult {
        delay(600) // realistic network check latency
        val cleanUid = uid.trim()
        if (cleanUid.length !in 8..11 || !cleanUid.all { it.isDigit() }) {
            return UidVerificationResult(
                isValid = false,
                uid = cleanUid,
                errorMessage = "Invalid UID. Free Fire BD Player UIDs must contain 8-11 digits."
            )
        }

        val sampleIgns = listOf(
            "★⚡RASTAR_FF⚡★",
            "亗 Ｍ Ａ Ｆ Ｉ Ａ 亗",
            "OP_SNIPER_BD",
            "BD_HEADSHOT_KING",
            "꧁༺NINJA_FF༻꧂",
            "CYBER_WARRIOR_BD",
            "TITAN_KILLER_99",
            "★BD_GHOST_BOY★"
        )
        val hash = cleanUid.hashCode().let { if (it < 0) -it else it }
        val ign = sampleIgns[hash % sampleIgns.size]
        val level = 50 + (hash % 30)

        return UidVerificationResult(
            isValid = true,
            uid = cleanUid,
            ign = ign,
            level = level,
            region = "BD (Bangladesh)"
        )
    }
}
