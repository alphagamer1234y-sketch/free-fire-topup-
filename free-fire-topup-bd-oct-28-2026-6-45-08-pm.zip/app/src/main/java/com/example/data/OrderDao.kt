package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.TopupOrder
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM topup_orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<TopupOrder>>

    @Query("SELECT * FROM topup_orders WHERE orderId = :orderId LIMIT 1")
    suspend fun getOrderById(orderId: String): TopupOrder?

    @Query("SELECT * FROM topup_orders WHERE orderId = :orderId LIMIT 1")
    fun getOrderFlow(orderId: String): Flow<TopupOrder?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: TopupOrder)

    @Update
    suspend fun updateOrder(order: TopupOrder)

    @Query("DELETE FROM topup_orders WHERE orderId = :orderId")
    suspend fun deleteOrder(orderId: String)
}
