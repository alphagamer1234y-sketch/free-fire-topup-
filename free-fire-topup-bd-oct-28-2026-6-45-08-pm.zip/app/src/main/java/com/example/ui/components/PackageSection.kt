package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PackageCategory
import com.example.model.TopupPackage
import com.example.model.TopupPackages
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BorderDark
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.EmberOrange
import com.example.ui.theme.GoldRoyale
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceHoverDark
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PackageSection(
    selectedPackage: TopupPackage,
    onSelectPackage: (TopupPackage) -> Unit,
    activeCategory: PackageCategory?,
    onCategoryChanged: (PackageCategory?) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("package_section_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(DiamondCyan.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "2",
                            color = DiamondCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SELECT DIAMOND PACKAGE",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        letterSpacing = 0.5.sp
                    )
                }

                Text(
                    text = "${TopupPackages.ALL.size} Packages",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Category Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = activeCategory == null,
                    onClick = { onCategoryChanged(null) },
                    label = { Text("All", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmberOrange,
                        selectedLabelColor = Color.Black,
                        containerColor = SurfaceVariantDark,
                        labelColor = TextSecondary
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                FilterChip(
                    selected = activeCategory == PackageCategory.DIAMONDS,
                    onClick = { onCategoryChanged(PackageCategory.DIAMONDS) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Diamond,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (activeCategory == PackageCategory.DIAMONDS) Color.Black else DiamondCyan
                        )
                    },
                    label = { Text("Diamonds", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = DiamondCyan,
                        selectedLabelColor = Color.Black,
                        containerColor = SurfaceVariantDark,
                        labelColor = TextSecondary
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                FilterChip(
                    selected = activeCategory == PackageCategory.MEMBERSHIP,
                    onClick = { onCategoryChanged(PackageCategory.MEMBERSHIP) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (activeCategory == PackageCategory.MEMBERSHIP) Color.Black else GoldRoyale
                        )
                    },
                    label = { Text("Passes", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldRoyale,
                        selectedLabelColor = Color.Black,
                        containerColor = SurfaceVariantDark,
                        labelColor = TextSecondary
                    ),
                    shape = RoundedCornerShape(10.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Grid of Packages
            val filteredList = TopupPackages.ALL.filter {
                activeCategory == null || it.category == activeCategory
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                maxItemsInEachRow = 2
            ) {
                filteredList.forEach { pkg ->
                    PackageGridItem(
                        pkg = pkg,
                        isSelected = selectedPackage.id == pkg.id,
                        onSelect = { onSelectPackage(pkg) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("package_item_${pkg.id}")
                    )
                }
            }
        }
    }
}

@Composable
fun PackageGridItem(
    pkg: TopupPackage,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isMembership = pkg.category == PackageCategory.MEMBERSHIP

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect() },
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) SurfaceHoverDark else SurfaceVariantDark,
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) {
                if (isMembership) GoldRoyale else DiamondCyan
            } else BorderDark
        )
    ) {
        Box(modifier = Modifier.padding(10.dp)) {
            // Selected Check Icon
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(if (isMembership) GoldRoyale else DiamondCyan),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Selected",
                        tint = Color.Black,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Column {
                // Badge if any
                if (pkg.badge != null) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isMembership) GoldRoyale.copy(alpha = 0.2f) else EmberOrange.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(
                            0.5.dp,
                            if (isMembership) GoldRoyale else EmberOrange
                        )
                    ) {
                        Text(
                            text = pkg.badge,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            color = if (isMembership) GoldRoyale else EmberOrange,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Diamond icon & Name
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isMembership) Icons.Default.WorkspacePremium else Icons.Default.Diamond,
                        contentDescription = null,
                        tint = if (isMembership) GoldRoyale else DiamondCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = pkg.name,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                if (pkg.bonusInfo != null) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = pkg.bonusInfo,
                        fontSize = 10.sp,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Price Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "💸 ${pkg.price}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isSelected) EmberOrange else TextPrimary
                    )

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isSelected) EmberOrange.copy(alpha = 0.25f) else Color(0x33000000)
                    ) {
                        Text(
                            text = "INSTANT",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) EmberOrange else TextMuted,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
