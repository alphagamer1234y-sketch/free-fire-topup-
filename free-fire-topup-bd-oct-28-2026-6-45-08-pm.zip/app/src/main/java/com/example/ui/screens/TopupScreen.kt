package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.ShoppingCartCheckout
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfile
import com.example.ui.components.CheckoutSuccessDialog
import com.example.ui.components.HeaderBanner
import com.example.ui.components.PackageSection
import com.example.ui.components.PaymentMethodSelector
import com.example.ui.components.ScreenshotUploadSection
import com.example.ui.components.UidInputSection
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.EmberOrange
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.TopupViewModel

@Composable
fun TopupScreen(
    viewModel: TopupViewModel,
    onOpenProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 90.dp) // space for bottom sticky bar
        ) {
            item {
                HeaderBanner(
                    userProfile = userProfile,
                    onProfileClick = onOpenProfile
                )
            }

            item {
                UidInputSection(
                    playerUid = uiState.playerUid,
                    onUidChange = { viewModel.onUidChanged(it) },
                    verifiedIgn = uiState.verifiedIgn,
                    verifiedLevel = uiState.verifiedLevel,
                    isVerifying = uiState.isVerifyingUid,
                    errorMessage = uiState.uidError,
                    onVerifyClick = { viewModel.verifyPlayerUid() },
                    savedUids = userProfile.savedUids
                )
            }

            item {
                PackageSection(
                    selectedPackage = uiState.selectedPackage,
                    onSelectPackage = { viewModel.selectPackage(it) },
                    activeCategory = uiState.filterCategory,
                    onCategoryChanged = { viewModel.setCategoryFilter(it) }
                )
            }

            item {
                PaymentMethodSelector(
                    selectedPayment = uiState.selectedPayment,
                    onSelectPayment = { viewModel.selectPayment(it) },
                    amountDue = uiState.selectedPackage.price
                )
            }

            item {
                ScreenshotUploadSection(
                    screenshotUri = uiState.screenshotUri,
                    onScreenshotSelected = { viewModel.onScreenshotSelected(it) },
                    onUseSampleScreenshot = { viewModel.setSampleScreenshot() },
                    transactionId = uiState.transactionId,
                    onTransactionIdChanged = { viewModel.onTransactionIdChanged(it) },
                    senderNumber = uiState.senderNumber,
                    onSenderNumberChanged = { viewModel.onSenderNumberChanged(it) },
                    paymentMethodName = uiState.selectedPayment.name
                )
            }

            // Error Message Banner if validation failed
            if (uiState.errorMessage != null) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("checkout_error_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CrimsonRed.copy(alpha = 0.15f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRed)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = CrimsonRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = uiState.errorMessage ?: "",
                                fontSize = 12.sp,
                                color = CrimsonRed,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // Bottom Sticky Action Bar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            color = SurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark),
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Total Payable:",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "💸 ${uiState.selectedPackage.price}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = EmberOrange
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "(${uiState.selectedPackage.diamonds}💎)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = DiamondCyan
                        )
                    }
                }

                Button(
                    onClick = { viewModel.submitTopupOrder() },
                    enabled = !uiState.isSubmitting,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmberOrange,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("submit_topup_order_button")
                ) {
                    if (uiState.isSubmitting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.Black,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SUBMIT TOP-UP",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }

        // Success Dialog
        if (uiState.showCheckoutSuccessDialog && uiState.newlyPlacedOrderId != null) {
            CheckoutSuccessDialog(
                orderId = uiState.newlyPlacedOrderId ?: "",
                playerUid = uiState.playerUid,
                playerName = uiState.verifiedIgn ?: "Player",
                packageTitle = uiState.selectedPackage.name,
                price = uiState.selectedPackage.price,
                paymentMethod = uiState.selectedPayment.name,
                onTrackOrder = { viewModel.dismissSuccessDialogAndTrack() },
                onDismiss = { viewModel.dismissSuccessDialogAndTrack() }
            )
        }
    }
}
