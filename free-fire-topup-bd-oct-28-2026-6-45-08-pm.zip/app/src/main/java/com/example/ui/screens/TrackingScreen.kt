package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderStatus
import com.example.model.TopupOrder
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DiamondCyan
import com.example.ui.theme.EmberOrange
import com.example.ui.theme.GoldRoyale
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceHoverDark
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.TopupViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TrackingScreen(
    viewModel: TopupViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val orders by viewModel.ordersList.collectAsState()
    val activeOrderId by viewModel.activeTrackOrderId.collectAsState()

    var searchInput by remember { mutableStateOf("") }

    val currentOrder = orders.firstOrNull { it.orderId == activeOrderId }
        ?: orders.firstOrNull()

    fun copyReceipt(order: TopupOrder) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = """
            --- FREE FIRE TOPUP BD RECEIPT ---
            Order ID: ${order.orderId}
            Player UID: ${order.playerUid} (${order.playerName})
            Package: ${order.packageTitle} (${order.diamondsAmount} 💎)
            Amount: 💸 ${order.price}
            Method: ${order.paymentMethod}
            Txn ID: ${order.transactionId}
            Status: ${order.status.title}
            Time: ${SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(order.createdAt))}
            Support: +977-9801234567 / support@fftopup.com
        """.trimIndent()
        val clip = ClipData.newPlainText("Topup Receipt", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Full receipt copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("tracking_dashboard_screen")
    ) {
        item {
            // Screen Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(NeonGreen)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "REAL-TIME TRACKING",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary,
                            letterSpacing = 0.8.sp
                        )
                    }
                    Text(
                        text = "Live Free Fire BD Server Sync Status",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceVariantDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = null,
                            tint = DiamondCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "LIVE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = DiamondCyan
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }

        // Search or select order bar
        item {
            OutlinedTextField(
                value = searchInput,
                onValueChange = { searchInput = it },
                placeholder = { Text("Track by Order ID (e.g. FF-89214)", color = TextMuted, fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = EmberOrange
                    )
                },
                trailingIcon = {
                    if (searchInput.isNotBlank()) {
                        Button(
                            onClick = {
                                val match = orders.firstOrNull { it.orderId.equals(searchInput.trim(), ignoreCase = true) }
                                if (match != null) {
                                    viewModel.setActiveTrackOrder(match.orderId)
                                    Toast.makeText(context, "Tracking Order ${match.orderId}", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Order not found", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmberOrange, contentColor = Color.Black),
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .height(38.dp)
                        ) {
                            Text("Find", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("track_order_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmberOrange,
                    unfocusedBorderColor = BorderDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark
                )
            )

            Spacer(modifier = Modifier.height(12.dp))
        }

        // Active Order Chips list
        if (orders.isNotEmpty()) {
            item {
                Text(
                    text = "Recent Orders:",
                    fontSize = 11.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(orders) { ord ->
                        val isSelected = currentOrder?.orderId == ord.orderId
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) EmberOrange.copy(alpha = 0.2f) else SurfaceDark,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) EmberOrange else BorderDark
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { viewModel.setActiveTrackOrder(ord.orderId) }
                                .testTag("order_chip_${ord.orderId}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (ord.status) {
                                                OrderStatus.COMPLETED -> NeonGreen
                                                OrderStatus.PROCESSING -> DiamondCyan
                                                OrderStatus.VERIFYING -> GoldRoyale
                                                else -> EmberOrange
                                            }
                                        )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = ord.orderId,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) EmberOrange else TextPrimary
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "(${ord.diamondsAmount}💎)",
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        if (currentOrder != null) {
            item {
                // MAIN LIVE STATUS TRACKER CARD
                LiveTrackingStatusCard(
                    order = currentOrder,
                    onSimulateFastTrack = { viewModel.fastTrackSimulate(currentOrder.orderId) },
                    onCopyReceipt = { copyReceipt(currentOrder) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                // Order Details Breakdown
                OrderDetailsCard(order = currentOrder)
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                // Customer Support Section
                SupportCard(orderId = currentOrder.orderId)
            }
        } else {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Orders to Track Yet",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Place a top-up on the Top Up tab to track your diamonds in real-time.",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun LiveTrackingStatusCard(
    order: TopupOrder,
    onSimulateFastTrack: () -> Unit,
    onCopyReceipt: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val stepIndex = order.status.stepIndex.coerceAtLeast(0)
    val progressFloat = when (order.status) {
        OrderStatus.PENDING -> 0.25f
        OrderStatus.VERIFYING -> 0.50f
        OrderStatus.PROCESSING -> 0.75f
        OrderStatus.COMPLETED -> 1.0f
        OrderStatus.REJECTED -> 1.0f
    }

    val statusColor = when (order.status) {
        OrderStatus.COMPLETED -> NeonGreen
        OrderStatus.PROCESSING -> DiamondCyan
        OrderStatus.VERIFYING -> GoldRoyale
        OrderStatus.REJECTED -> CrimsonRed
        else -> EmberOrange
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("live_tracking_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, statusColor.copy(alpha = 0.7f))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Top row with Order ID & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ORDER #${order.orderId}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(order.createdAt)),
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = statusColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, statusColor)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (order.status != OrderStatus.COMPLETED && order.status != OrderStatus.REJECTED) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .scale(pulseScale)
                                    .clip(CircleShape)
                                    .background(statusColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = order.status.title.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = statusColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Real-Time Progress Bar
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Delivery Progress",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )
                    Text(
                        text = "${(progressFloat * 100).toInt()}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { progressFloat },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = statusColor,
                    trackColor = SurfaceVariantDark
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 4-Stage Visual Milestones Stepper
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                TrackingStepRow(
                    stepNum = 1,
                    title = "Order & Screenshot Submitted",
                    description = "Payment via ${order.paymentMethod} (Ref: ${order.transactionId})",
                    isDone = stepIndex >= 0,
                    isActive = stepIndex == 0
                )

                TrackingStepRow(
                    stepNum = 2,
                    title = "Payment Proof Verified",
                    description = "Gateway confirmed amount 💸 ${order.price}",
                    isDone = stepIndex >= 1,
                    isActive = stepIndex == 1
                )

                TrackingStepRow(
                    stepNum = 3,
                    title = "Free Fire BD Server Injection",
                    description = "Connecting API to Player UID ${order.playerUid}",
                    isDone = stepIndex >= 2,
                    isActive = stepIndex == 2
                )

                TrackingStepRow(
                    stepNum = 4,
                    title = "Diamonds Credited (Completed)",
                    description = "${order.diamondsAmount} Diamonds deposited to ${order.playerName}",
                    isDone = stepIndex >= 3,
                    isActive = stepIndex == 3
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Live status note
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceVariantDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = order.statusNote,
                        fontSize = 12.sp,
                        color = TextPrimary,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons: Fast-Track Simulation & Copy Receipt
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (order.status != OrderStatus.COMPLETED) {
                    Button(
                        onClick = onSimulateFastTrack,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmberOrange,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("fast_track_simulation_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Live 30s Fast-Track ⚡",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                OutlinedButton(
                    onClick = onCopyReceipt,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("copy_receipt_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        tint = DiamondCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Copy Receipt",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DiamondCyan
                    )
                }
            }
        }
    }
}

@Composable
fun TrackingStepRow(
    stepNum: Int,
    title: String,
    description: String,
    isDone: Boolean,
    isActive: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    when {
                        isDone && !isActive -> NeonGreen
                        isActive -> EmberOrange
                        else -> SurfaceVariantDark
                    }
                )
                .border(
                    1.dp,
                    if (isActive) EmberOrange else BorderDark,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isDone && !isActive) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(16.dp)
                )
            } else {
                Text(
                    text = "$stepNum",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) Color.Black else TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = if (isActive || isDone) FontWeight.Bold else FontWeight.Medium,
                color = if (isActive) EmberOrange else if (isDone) TextPrimary else TextMuted
            )
            Text(
                text = description,
                fontSize = 11.sp,
                color = if (isActive) TextSecondary else TextMuted,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
fun OrderDetailsCard(order: TopupOrder) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "TRANSACTION BREAKDOWN",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            DetailRow(label = "Player UID", value = "${order.playerUid} (${order.playerName})")
            DetailRow(label = "Server Region", value = order.serverRegion)
            DetailRow(label = "Diamond Package", value = "${order.packageTitle} (${order.diamondsAmount} 💎)")
            DetailRow(label = "Total Price", value = "💸 ${order.price}", isHighlight = true)
            DetailRow(label = "Payment Gateway", value = order.paymentMethod)
            DetailRow(label = "Transaction Ref", value = order.transactionId)
            DetailRow(label = "Sender Account", value = order.senderNumber)
            DetailRow(label = "Proof Status", value = if (order.screenshotUri != null) "Verified Screenshot" else "Pending")
        }
    }
}

@Composable
fun DetailRow(label: String, value: String, isHighlight: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp, color = TextMuted)
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = if (isHighlight) FontWeight.ExtraBold else FontWeight.SemiBold,
            color = if (isHighlight) EmberOrange else TextPrimary
        )
    }
}

@Composable
fun SupportCard(orderId: String) {
    val context = LocalContext.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceVariantDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.SupportAgent,
                    contentDescription = null,
                    tint = DiamondCyan,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Need Help with Order #$orderId?",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Our Free Fire Top-Up specialists are available 24/7 on WhatsApp & Telegram to resolve any payment or UID verification queries.",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        Toast.makeText(context, "Contacting WhatsApp Support: +977-9801234567", Toast.LENGTH_LONG).show()
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF25D366),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("WhatsApp Support", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        Toast.makeText(context, "Telegram Support: @FFTopupBD_Help", Toast.LENGTH_LONG).show()
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0088CC),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Telegram Channel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
