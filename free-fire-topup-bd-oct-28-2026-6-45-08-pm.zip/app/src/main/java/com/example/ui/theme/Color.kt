package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmberOrange = Color(0xFFFF6B00)
val EmberOrangeLight = Color(0xFFFF8833)
val DiamondCyan = Color(0xFF00D2FF)
val DiamondCyanDark = Color(0xFF0094B8)
val GoldRoyale = Color(0xFFFFB800)
val CrimsonRed = Color(0xFFFF3B30)
val NeonGreen = Color(0xFF00E676)

// Dark Theme Surfaces
val BackgroundDark = Color(0xFF0B0F19)
val SurfaceDark = Color(0xFF131929)
val SurfaceVariantDark = Color(0xFF1C2438)
val SurfaceHoverDark = Color(0xFF26314D)
val BorderDark = Color(0xFF2B3650)

// Text Colors
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Payment Brand Colors
val EsewaGreen = Color(0xFF60BB46)
val KhaltiPurple = Color(0xFF5C2D91)
val ImePayRed = Color(0xFFED1C24)
