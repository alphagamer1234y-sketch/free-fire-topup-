package com.example.model

enum class AuthProvider {
    GUEST,
    PHONE,
    GOOGLE
}

data class UserProfile(
    val isLoggedIn: Boolean = false,
    val authProvider: AuthProvider = AuthProvider.GUEST,
    val displayName: String = "Guest Gamer",
    val identifier: String = "Not logged in", // Phone or Email
    val avatarUrl: String? = null,
    val savedUids: List<String> = emptyList(),
    val totalOrders: Int = 0,
    val totalDiamondsOrdered: Int = 0
)
