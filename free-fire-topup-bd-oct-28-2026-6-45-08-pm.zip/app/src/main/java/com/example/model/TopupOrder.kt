package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class OrderStatus(val title: String, val stepIndex: Int, val description: String) {
    PENDING("Order Placed", 0, "Payment proof submitted. Waiting for verification queue."),
    VERIFYING("Verifying Payment", 1, "Matching screenshot & transaction ID with payment gateway."),
    PROCESSING("Top-up Processing", 2, "Connecting to Free Fire BD Server API to credit diamonds."),
    COMPLETED("Completed 💎", 3, "Diamonds successfully added to your in-game Free Fire account!"),
    REJECTED("Rejected", -1, "Invalid transaction code or illegible screenshot. Contact support.")
}

@Entity(tableName = "topup_orders")
data class TopupOrder(
    @PrimaryKey
    val orderId: String,
    val playerUid: String,
    val playerName: String,
    val serverRegion: String = "BD (Bangladesh)",
    val packageId: String,
    val packageTitle: String,
    val diamondsAmount: Int,
    val price: Int,
    val paymentMethod: String,
    val transactionId: String,
    val senderNumber: String,
    val screenshotUri: String? = null,
    val status: OrderStatus = OrderStatus.PENDING,
    val statusNote: String = "Processing usually takes 2 to 5 minutes.",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
