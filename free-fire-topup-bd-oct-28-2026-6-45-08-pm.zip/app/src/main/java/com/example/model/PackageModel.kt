package com.example.model

enum class PackageCategory {
    DIAMONDS,
    MEMBERSHIP
}

data class TopupPackage(
    val id: String,
    val name: String,
    val diamonds: Int,
    val price: Int, // Price in currency (NPR / BDT)
    val category: PackageCategory,
    val badge: String? = null,
    val bonusInfo: String? = null,
    val isPopular: Boolean = false
)

object TopupPackages {
    val ALL: List<TopupPackage> = listOf(
        // Passes & Memberships
        TopupPackage(
            id = "pkg_weekly_lite",
            name = "Weekly Lite",
            diamonds = 120,
            price = 70,
            category = PackageCategory.MEMBERSHIP,
            badge = "DAILY CLAIM",
            bonusInfo = "Total 120💎 (20💎/day for 6 days)"
        ),
        TopupPackage(
            id = "pkg_weekly",
            name = "Weekly Membership",
            diamonds = 450,
            price = 210,
            category = PackageCategory.MEMBERSHIP,
            badge = "VIP BADGE",
            bonusInfo = "Total 450💎 + Special Icon & Gun Skin Trial",
            isPopular = true
        ),
        TopupPackage(
            id = "pkg_monthly",
            name = "Monthly Membership",
            diamonds = 2600,
            price = 1025,
            category = PackageCategory.MEMBERSHIP,
            badge = "SUPER VIP",
            bonusInfo = "Total 2600💎 + 5x Discount Store Voucher + VIP Hat",
            isPopular = true
        ),

        // Standard Diamonds
        TopupPackage("pkg_115", "115 Diamonds", 115, 105, PackageCategory.DIAMONDS, bonusInfo = "+10 Bonus"),
        TopupPackage("pkg_240", "240 Diamonds", 240, 210, PackageCategory.DIAMONDS, bonusInfo = "+20 Bonus"),
        TopupPackage("pkg_355", "355 Diamonds", 355, 310, PackageCategory.DIAMONDS, bonusInfo = "+35 Bonus"),
        TopupPackage("pkg_480", "480 Diamonds", 480, 415, PackageCategory.DIAMONDS, bonusInfo = "+48 Bonus"),
        TopupPackage("pkg_610", "610 Diamonds", 610, 515, PackageCategory.DIAMONDS, bonusInfo = "+60 Bonus", isPopular = true),
        TopupPackage("pkg_725", "725 Diamonds", 725, 620, PackageCategory.DIAMONDS, bonusInfo = "+75 Bonus"),
        TopupPackage("pkg_850", "850 Diamonds", 850, 720, PackageCategory.DIAMONDS, bonusInfo = "+85 Bonus"),
        TopupPackage("pkg_965", "965 Diamonds", 965, 825, PackageCategory.DIAMONDS, bonusInfo = "+95 Bonus"),
        TopupPackage("pkg_1090", "1090 Diamonds", 1090, 925, PackageCategory.DIAMONDS, badge = "BEST VALUE", bonusInfo = "+110 Bonus", isPopular = true),
        TopupPackage("pkg_1240", "1240 Diamonds", 1240, 1030, PackageCategory.DIAMONDS, bonusInfo = "+125 Bonus"),
        TopupPackage("pkg_1480", "1480 Diamonds", 1480, 1230, PackageCategory.DIAMONDS, bonusInfo = "+150 Bonus"),
        TopupPackage("pkg_1595", "1595 Diamonds", 1595, 1335, PackageCategory.DIAMONDS, bonusInfo = "+160 Bonus"),
        TopupPackage("pkg_1720", "1720 Diamonds", 1720, 1435, PackageCategory.DIAMONDS, bonusInfo = "+170 Bonus"),
        TopupPackage("pkg_1965", "1965 Diamonds", 1965, 1640, PackageCategory.DIAMONDS, bonusInfo = "+195 Bonus"),
        TopupPackage("pkg_2090", "2090 Diamonds", 2090, 1740, PackageCategory.DIAMONDS, bonusInfo = "+210 Bonus"),
        TopupPackage("pkg_2530", "2530 Diamonds", 2530, 2060, PackageCategory.DIAMONDS, badge = "PRO GAMER", bonusInfo = "+255 Bonus", isPopular = true),
        TopupPackage("pkg_3770", "3770 Diamonds", 3770, 3090, PackageCategory.DIAMONDS, bonusInfo = "+380 Bonus"),
        TopupPackage("pkg_5060", "5060 Diamonds", 5060, 4120, PackageCategory.DIAMONDS, badge = "GUILD LEADER", bonusInfo = "+510 Bonus"),
        TopupPackage("pkg_7590", "7590 Diamonds", 7590, 6180, PackageCategory.DIAMONDS, bonusInfo = "+760 Bonus"),
        TopupPackage("pkg_10120", "10120 Diamonds", 10120, 8240, PackageCategory.DIAMONDS, badge = "MEGA BUNDLE", bonusInfo = "+1020 Bonus"),
        TopupPackage("pkg_15180", "15180 Diamonds", 15180, 12360, PackageCategory.DIAMONDS, bonusInfo = "+1520 Bonus"),
        TopupPackage("pkg_20240", "20240 Diamonds", 20240, 16540, PackageCategory.DIAMONDS, badge = "WHALE PACK", bonusInfo = "+2050 Bonus")
    )
}
