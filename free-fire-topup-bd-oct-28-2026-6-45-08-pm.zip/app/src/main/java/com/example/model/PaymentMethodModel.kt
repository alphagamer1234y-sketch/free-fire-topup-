package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.EsewaGreen
import com.example.ui.theme.ImePayRed
import com.example.ui.theme.KhaltiPurple

enum class PaymentType {
    ESEWA,
    KHALTI,
    IME_PAY
}

data class PaymentMethodInfo(
    val type: PaymentType,
    val name: String,
    val brandColor: Color,
    val accountId: String,
    val accountName: String,
    val qrDrawableName: String = "",
    val instructions: List<String>,
    val note: String
)

object PaymentMethods {
    val ALL: List<PaymentMethodInfo> = listOf(
        PaymentMethodInfo(
            type = PaymentType.ESEWA,
            name = "eSewa",
            brandColor = EsewaGreen,
            accountId = "9801234567",
            accountName = "FF TOPUP BD OFFICIAL",
            instructions = listOf(
                "Open your eSewa application.",
                "Send Money / Transfer exact amount to ID: 9801234567",
                "Enter your Free Fire Player UID in the Remarks field.",
                "After payment, copy the Transaction Code and take a screenshot."
            ),
            note = "Instant verification supported 24/7."
        ),
        PaymentMethodInfo(
            type = PaymentType.KHALTI,
            name = "Khalti",
            brandColor = KhaltiPurple,
            accountId = "9801234567",
            accountName = "FF TOPUP BD OFFICIAL",
            instructions = listOf(
                "Open your Khalti Wallet app.",
                "Send Money to Khalti Mobile Number: 9801234567",
                "Type your Free Fire UID in Purpose/Remarks.",
                "Copy the 10-digit Khalti Transaction ID and attach receipt screenshot."
            ),
            note = "Fast 1-click verification via Khalti reference."
        ),
        PaymentMethodInfo(
            type = PaymentType.IME_PAY,
            name = "IME Pay",
            brandColor = ImePayRed,
            accountId = "9801234567",
            accountName = "FF TOPUP BD OFFICIAL",
            instructions = listOf(
                "Launch the IME Pay app.",
                "Transfer to IME Pay Wallet: 9801234567",
                "Write your Player UID in the Transfer Note.",
                "Save transaction receipt and copy the Transaction Reference ID."
            ),
            note = "Zero transfer fee with instant processing."
        )
    )
}
