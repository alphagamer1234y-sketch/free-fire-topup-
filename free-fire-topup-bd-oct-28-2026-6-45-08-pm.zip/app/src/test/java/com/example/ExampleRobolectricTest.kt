package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.TopupPackages
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Free Fire Topup BD", appName)
    }

    @Test
    fun `verify topup packages count and pricing`() {
        val packages = TopupPackages.ALL
        assertTrue(packages.isNotEmpty())

        val pkg115 = packages.first { it.id == "pkg_115" }
        assertEquals(115, pkg115.diamonds)
        assertEquals(105, pkg115.price)

        val monthly = packages.first { it.id == "pkg_monthly" }
        assertEquals(1025, monthly.price)

        val weekly = packages.first { it.id == "pkg_weekly" }
        assertEquals(210, weekly.price)

        val weeklyLite = packages.first { it.id == "pkg_weekly_lite" }
        assertEquals(70, weeklyLite.price)
    }
}
